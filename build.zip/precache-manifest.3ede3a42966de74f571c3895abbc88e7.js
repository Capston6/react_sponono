self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "58f1c4a00e20dcf4a3417410bd4a50e6",
    "url": "/index.html"
  },
  {
    "revision": "18f4e29c487dbd43d74f",
    "url": "/static/css/main.5ecd60fb.chunk.css"
  },
  {
    "revision": "9ad01ffe65174ecdd4e4",
    "url": "/static/js/2.af20b930.chunk.js"
  },
  {
    "revision": "0749163b59fbee32225059cb60c18af6",
    "url": "/static/js/2.af20b930.chunk.js.LICENSE.txt"
  },
  {
    "revision": "18f4e29c487dbd43d74f",
    "url": "/static/js/main.1714398e.chunk.js"
  },
  {
    "revision": "aef1e1b1ad94af27a40d",
    "url": "/static/js/runtime-main.3632fca9.js"
  }
]);